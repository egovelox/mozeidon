import { Runtime } from "webextension-polyfill"
export type Port = Runtime.Port
