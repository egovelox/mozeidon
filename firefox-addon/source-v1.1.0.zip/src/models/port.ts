export type Port = browser.runtime.Port
