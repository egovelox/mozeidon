export const ROOT_BOOKMARK_ID = 'toolbar_____'
export const BOOKMARK_TYPE = 'bookmark'
export const MAX_BOOKMARK_COUNT = 100000
export const MAX_HISTORY_ITEMS_COUNT = 100000

