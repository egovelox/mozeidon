export const ADDON_NAME = "mozeidon"
export const DEBUG = false
