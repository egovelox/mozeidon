export type Port = chrome.runtime.Port
